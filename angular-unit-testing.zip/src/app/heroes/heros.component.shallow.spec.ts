import { Component, Input, NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { of } from "rxjs";
import { Hero } from "../hero";
import { HeroService } from "../hero.service";
import { HeroesComponent } from "./heroes.component";

describe("HeroesComponent (shallow tests)", () => {
    let fixture: ComponentFixture<HeroesComponent>;
    let herosMockService;
    let HEROS = [];

    //mock the HeroComponent
    @Component({
        selector: 'app-hero',
        template: '<div></div>',
      })
      class FakeHeroComponent {
        @Input() hero: Hero;
      }
    //mock the HeroComponent
    

    beforeEach(() => {
        herosMockService = jasmine.createSpyObj(['getHeroes']);

        TestBed.configureTestingModule({
            declarations: [HeroesComponent, FakeHeroComponent],
            //schemas: [NO_ERRORS_SCHEMA],
            providers: [
                { provide: HeroService, useValue: herosMockService}
            ]
        });
        
        
        fixture = TestBed.createComponent<HeroesComponent>(HeroesComponent);

        HEROS = [
            { id: 100, name: "H1", strength: 10},
            { id: 200, name: "H2", strength: 20},
            { id: 300, name: "H3", strength: 5}
        ];
    });
    it("getHeros() must set the heros array of the component", () => {
        herosMockService.getHeroes.and.returnValue(of(HEROS));
        fixture.detectChanges();

        expect(fixture.componentInstance.heroes.length).toBe(3);
    });

    it("should create one li for each Hero", () => {
        herosMockService.getHeroes.and.returnValue(of(HEROS));
        fixture.detectChanges();

        expect(fixture.nativeElement.querySelectorAll('li').length).toBe(3);
    });
});