import { Component, Directive, Input, NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { Router } from "@angular/router";
import { of } from "rxjs";
import { Hero } from "../hero";
import { HeroService } from "../hero.service";
import { HeroComponent } from "../hero/hero.component";
import { HeroesComponent } from "./heroes.component";

//mock the routerLink directive
@Directive({
    selector: '[routerLink]',
    host: {'(click)': 'onClick()'}
})
class RouterLinkDirectiveStub
{
    @Input('routerLink') linkParams: any;
    navigatedTo: any;

    onClick()
    {
        this.navigatedTo = this.linkParams;
    }
}
//mock the routerLink directive


describe("HeroesComponent (deep tests)", () => {
    let fixture: ComponentFixture<HeroesComponent>;
    let herosMockService;
    let HEROS = [];


    beforeEach(() => {
        herosMockService = jasmine.createSpyObj(['getHeroes', 'addHero']);

        TestBed.configureTestingModule({
            declarations: [HeroesComponent, HeroComponent, RouterLinkDirectiveStub],
            //schemas: [NO_ERRORS_SCHEMA],
            providers: [
                { provide: HeroService, useValue: herosMockService}
            ]
        });
        
        
        fixture = TestBed.createComponent<HeroesComponent>(HeroesComponent);
        fixture = TestBed.createComponent(HeroesComponent);

        HEROS = [
            { id: 100, name: "H1", strength: 10},
            { id: 200, name: "H2", strength: 20},
            { id: 300, name: "H3", strength: 5}
        ];
    });
    it("should display the correct number of HeroComponent(s)", () => {
        herosMockService.getHeroes.and.returnValue(of(HEROS));
        fixture.detectChanges();

        let herocomponents = fixture.debugElement.queryAll(By.directive(HeroComponent));
        expect(herocomponents.length).toBe(3);
    });

    xit("should pass the correct Hero to each HeroComponent", () => {
        herosMockService.getHeroes.and.returnValue(of(HEROS));
        fixture.detectChanges();

        let herocomponents = fixture.debugElement.queryAll(By.directive(HeroComponent));
        for(let i=0 ; i<herocomponents.length ; i++)
        {
            expect(herocomponents[i].componentInstance.hero).toEqual(HEROS[i]);
        }
    });



    //testing events on elements
    xit("should call delete() on parent when a Hero component's delete button is clicked", () => {

        //create a method to spy on
        spyOn(fixture.componentInstance, 'delete');
        //create a method to spy on

        //let eventarg = jasmine.createSpyObj(['stopPropagation']);

        herosMockService.getHeroes.and.returnValue(of(HEROS));
        fixture.detectChanges();
        

        //get all the HeroComponent(s)
        let herocomponents = fixture.debugElement.queryAll(By.directive(HeroComponent));

        //locate the button and trigger the click event
        herocomponents[0].query(By.css("button")).triggerEventHandler('click', {stopPropagation: () => {}});
        //herocomponents[0].query(By.css("button")).triggerEventHandler('click', eventarg);

        //check if the event handler was indeed called
        expect(fixture.componentInstance.delete).toHaveBeenCalledWith(HEROS[0]);
    });


    //emitting events directly from children
    xit("should call delete() on parent when a Hero component's delete button is clicked - EMIT EVENT DIRECTLY", () => {

        //create a method to spy on
        spyOn(fixture.componentInstance, 'delete');
        //create a method to spy on

        herosMockService.getHeroes.and.returnValue(of(HEROS));
        fixture.detectChanges();

        //get all the HeroComponent(s)
        let herocomponents = fixture.debugElement.queryAll(By.directive(HeroComponent));

        //emit the delete event directly
        let herocomponent: HeroComponent = herocomponents[0].componentInstance;
        herocomponent.delete.emit();
        //(<HeroComponent>herocomponents[0].componentInstance).delete.emit(undefined);

        //check if the event handler was indeed called
        expect(fixture.componentInstance.delete).toHaveBeenCalledWith(HEROS[0]);
    });

    //check value of input box
    xit("should add a new Hero when the Add button is clicked", () => {
        herosMockService.getHeroes.and.returnValue(of(HEROS));
        fixture.detectChanges();

        const name = "Mr. ABC";

        //set the return value of addHero of the mock service
        const hero = {id: 999, name: name, strength: 6};
        herosMockService.addHero.and.returnValue(of(hero));

        //get the input box
        const inputElement = fixture.debugElement.query(By.css('input')).nativeElement;

        //set the value in the input box
        inputElement.value = name;

        //get the Add button
        const addButton = fixture.debugElement.queryAll(By.css('button'))[0];

        //trigger the click event
        addButton.triggerEventHandler('click', null);
        //fixture.detectChanges();

        //check if the newly added hero appears in the template
        expect(HEROS[3]).toEqual(hero);


        //home work
        //check if the template of the HeroComponent displays the newly added hero's name
        //home work
    });

    //spec to check that when the element with the routerLink is clicked
    //it must have the correct hero link configured
    it("should have the correct hero's link when the link is clicked", () => {
        herosMockService.getHeroes.and.returnValue(of(HEROS));
        fixture.detectChanges();

        //get all the app-hero components
        let heroes = fixture.debugElement.queryAll(By.directive(HeroComponent));
        console.log("Total: " +heroes.length);

        //get the routerLink for the first hero
        let routerlink = heroes[0]
            .query(By.directive(RouterLinkDirectiveStub))
            .injector.get(RouterLinkDirectiveStub);

        // //click the anchor tag
        heroes[0].query(By.css('a')).triggerEventHandler('click', null);

        // //check the navigatedTo prop of the routerLink
        expect(routerlink.navigatedTo).toBe('/detail/100');
    });
});