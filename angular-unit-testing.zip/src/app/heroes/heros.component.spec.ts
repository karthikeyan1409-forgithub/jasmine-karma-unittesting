import { HeroesComponent } from "./heroes.component";
import { of } from "rxjs";

describe("HerosComponent", () => {
    let heroscomp: HeroesComponent;
    let herosServiceMock;
    let HEROS;

    beforeEach(() => {
        herosServiceMock = jasmine.createSpyObj(['deleteHero'])
        heroscomp = new HeroesComponent(herosServiceMock);
        HEROS = [
            {id: 1, name: 'HERO1', strength: 5},
            {id: 2, name: 'HERO2', strength: 25},
            {id: 3, name: 'HERO2', strength: 10}
        ];
    });
    it("delete() method should delete the hero passed to it", () => {
        console.log(HEROS.length);
        
        //make the method of the mocked service return some value
        herosServiceMock.deleteHero.and.returnValue(of(""))

        heroscomp.heroes = HEROS;
        heroscomp.delete(HEROS[2]);
        expect(heroscomp.heroes.length).toBe(2);
    });

    //interaction test - to check if a method calls another method or not
    it("delete() method must call deleteHero() of the service", () => {
        herosServiceMock.deleteHero.and.returnValue(of(""))

        heroscomp.heroes = HEROS;
        heroscomp.delete(HEROS[2]);
        expect(herosServiceMock.deleteHero).toHaveBeenCalled();
    });

    xit("delete() method must call deleteHero() with a Hero object", () => {
        herosServiceMock.deleteHero.and.returnValue(of(""))

        heroscomp.heroes = HEROS;
        heroscomp.delete(HEROS[2]);
        expect(herosServiceMock.deleteHero).toHaveBeenCalledWith(HEROS[2]);
    });
});