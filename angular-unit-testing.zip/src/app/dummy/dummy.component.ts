import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dummy',
  templateUrl: './dummy.component.html',
  styleUrls: ['./dummy.component.css']
})
export class DummyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  HandleClick(): void
  {
    console.log("Click handled internally");
    this.LogMessage();
  }

  LogMessage(): void
  {
    console.log("Click handled externally");
  }

  DoSave()
  {
    setTimeout(() => {
      this.Save();
    }, 3000);
  }

  Save()
  {
    console.log("SAVED");
  }
  

}
