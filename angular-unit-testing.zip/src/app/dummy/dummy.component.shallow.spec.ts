import { flush, tick } from "@angular/core/testing";
import { ComponentFixture, fakeAsync, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { DummyComponent } from "./dummy.component";

describe("DummyComponent", () => {
    let fixture: ComponentFixture<DummyComponent>;
    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [DummyComponent]
        });
    fixture = TestBed.createComponent<DummyComponent>(DummyComponent);
    spyOn(fixture.componentInstance, 'LogMessage');
    });

    // it("should call LogMessage() when the button is clicked", () => {
    //     //1. Locate the button
    //     let buttonelement = fixture.debugElement.query(By.css("button"));
    //     buttonelement.triggerEventHandler('click', null);
    //     expect(fixture.componentInstance.LogMessage).toHaveBeenCalled();
    // });

    // it("should call Save() when DoSave() is called", (done) => {
    //     spyOn(fixture.componentInstance, 'Save');
    //     fixture.componentInstance.DoSave();
        
    //     setTimeout(() => {
    //         done();     //tell Jasmine that the wait is over
    //         expect(fixture.componentInstance.Save).toHaveBeenCalled();
    //     },2999);

    //     //expect(fixture.componentInstance.Save).toHaveBeenCalled();
    // });

    it("should call Save() when DoSave() is called - ANGULAR STYLE ASNYC TEST", fakeAsync(() => {
        spyOn(fixture.componentInstance, 'Save');
        fixture.componentInstance.DoSave();     
        //tick(3000);
        flush();
        
        expect(fixture.componentInstance.Save).toHaveBeenCalled();
    }));

    


    // it("should call the Save() method when DoSave() is called", () => {
    //     //keep an eye on the Save() method
    //     spyOn(fixture.componentInstance, 'Save');

    //     //invoke DoSave()
    //     fixture.componentInstance.DoSave();

    //     // setTimeout(() => {
    //     //     expect(fixture.componentInstance.Save).toHaveBeenCalled();
    //     // },3001)

    //     //ask the spy if the method on which it was spying was called or not
    //     //expect(fixture.componentInstance.Save).toHaveBeenCalled();
    // });
});