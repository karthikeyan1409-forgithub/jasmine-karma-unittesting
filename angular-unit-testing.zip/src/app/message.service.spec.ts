import { MessageService } from "./message.service";

describe("MessageService", () => {
    let messagesvc: MessageService;

    beforeEach(() => {
        messagesvc = new MessageService();
    });
    it("addMessage should add a message", () => {
        messagesvc.add("message1");
        messagesvc.add("message2");

        expect(messagesvc.messages.length).toBe(2);
    });

    it("clear should clear all messages", () => {
        messagesvc.add("message1");
        messagesvc.add("message2");
        messagesvc.clear();

        expect(messagesvc.messages.length).toBe(0);
    });
});