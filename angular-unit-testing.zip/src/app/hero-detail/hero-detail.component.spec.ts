import { ComponentFixture, TestBed } from "@angular/core/testing";
import { HeroService } from "../hero.service";
import { Location } from '@angular/common';
import { ActivatedRoute } from "@angular/router";
import { HeroDetailComponent } from "./hero-detail.component";
import { of } from "rxjs";

describe("HeroDetailComponent", () => {
    let mockherosvc, mocklocationsvc, mockactivatedroute;
    let fixture: ComponentFixture<HeroDetailComponent>;
    
    // beforeEach(() => {
    //     mockherosvc = jasmine.createSpyObj(['getHero', 'updateHero']);
    //     mocklocationsvc = jasmine.createSpyObj(['back']);
    //     mockactivatedroute = {
    //         snapshot: {
    //             paramMap: { get: () => { return '5'; }}}
    //     }
        
    //     TestBed.configureTestingModule({
    //         declarations: [HeroDetailComponent],
    //         providers:[
    //             {provide: ActivatedRoute, useValue: mockactivatedroute},
    //             {provide: HeroService, useValue: mockherosvc},
    //             {provide: Location, useValue: mocklocationsvc}
    //         ]
    //     });
    // });
    // fixture = TestBed.createComponent<HeroDetailComponent>(HeroDetailComponent);
    // const hero = {id: 5, name: 'XYZ', strength: 100};
    // mockherosvc.getHero.and.returnValue(of({id: 5, name: 'XYZ', strength: 100}));

    // it("should display the hero name in <h2> element whose id has been clicked", () => {
    //     fixture.detectChanges();
    //     expect(fixture.nativeElement.querySelector('h2').textContent).toContain('XYZ');
    // });
});