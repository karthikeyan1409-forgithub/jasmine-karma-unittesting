import { TestBed, ComponentFixture } from "@angular/core/testing";
import { HeroComponent } from "./hero.component";
import { TestObject } from "protractor/built/driverProviders";
import { NO_ERRORS_SCHEMA } from "@angular/core";


describe("HeroComponent", () => {
    let fixture: ComponentFixture<HeroComponent>;

    beforeEach(() => {
        //configure the Angular environment
        TestBed.configureTestingModule({
            declarations:[HeroComponent],
            schemas: [NO_ERRORS_SCHEMA]
        });

        //instantiate the component
        fixture = TestBed.createComponent(HeroComponent);
    });

    it("@Input() hero must have a Hero object", () => {
        //set some value to the @Input() prop of the component
        fixture.componentInstance.hero = {id: 999, name: "ABC", strength: 100};

        expect(fixture.componentInstance.hero).toEqual({id: 999, name: "ABC", strength: 100});
    });

    it("<span> element must display the Hero name", () => {
        fixture.componentInstance.hero = {id: 999, name: "ABC", strength: 100};

        //check if the span element of the component's template contains the 
        //hero name or not
        //let text = fixture.nativeElement.querySelector('a').textContent;

        //kick start Angular's change detection process
        fixture.detectChanges();

        expect(fixture.nativeElement.querySelector('a').textContent).toContain("ABC");
    });
});