import { inject, TestBed } from "@angular/core/testing";
import { MessageService } from "./message.service";
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import { HeroService } from "./hero.service";

describe("HeroService", () => {
    let mockMessageService;
    let herosvc: HeroService;
    let httpclientmock: HttpTestingController;
    //let HEROS = [];
    
    beforeEach(() => {
        mockMessageService = jasmine.createSpyObj(['add']);

        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [HeroService,
                { provide: MessageService, useValue:mockMessageService}
            ]
        });
        //herosvc = TestBed.get(HeroService);
        //httpclientmock = TestBed.get(HttpTestingController);

        // HEROS = [
        //     { id: 100, name: "H1", strength: 10},
        //     { id: 200, name: "H2", strength: 20},
        //     { id: 300, name: "H3", strength: 5}
        // ];
    });
    it("should call getHero() with the correct URL", 
        inject([HeroService, HttpTestingController],
            (herosvc: HeroService, httpclientmock: HttpTestingController) =>
    {
        //invoke the getHero() method of HeroService
        herosvc.getHero(100).subscribe();
        // herosvc.getHero(101).subscribe();
        

        //ensure that the get() call was made with the correct URL
        let request = httpclientmock.expectOne('api/heroes/100');
        //httpclientmock.expectNone('api/heroes/101');

        //Required to check the return value only
            //request.flush({id: 102, name: "H1", strength: 10});
        //Required to check the return value only

        httpclientmock.verify();
    }));


    // it("should call getHero() with the correct URL", () =>
    // {
    //     //invoke the getHero() method of HeroService
    //     herosvc.getHero(100).subscribe();
        

    //     //ensure that the get() call was made with the correct URL
    //     let request = httpclientmock.expectOne('api/heroes/100');

    //     request.flush({id: 100, name: "H1", strength: 10});
    //     httpclientmock.verify();

    // });
});