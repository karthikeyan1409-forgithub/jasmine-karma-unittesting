import { getClosureSafeProperty } from "@angular/core/src/util/property";

//create a test suite
describe("FIRST TEST SUITE", () => {
    it("should be true if true" , () => {
        expect(true).toBe(true);
    });

    it("should be false if false" , () => {
        expect(false).toBe(false);
    });
});




