import {Account} from './account';

describe("Account class", () => {
    beforeEach(() => {
        console.log("BEFORE EACH CALLED");
    });

    afterEach(() => {
        console.log("AFTER EACH CALLED");
    });

   it("Withdraw should deduct the balance", () => {
        //ARRANGE
        let acc: Account = new Account(1000);

        //ACT
        acc.Withdraw(500);
        let balance = acc.CurrentBalance();

        //ASSERT
        expect(balance).toBe(500);
   });

   it("Deposit should increment the balance", () => {
       //ARRANGE
       let acc: Account = new Account(10000);

       //ACT
       acc.Deposit(5000);
       let balance = acc.CurrentBalance();

       //ASSERT
       expect(balance).toBe(15000);
   });

   it("CheckBalance should return the balance", () => {
       //ARRANGE
       let acc: Account = new Account(500);

       //ACT
       acc.Deposit(100);
       let balance = acc.CurrentBalance();

       //ASSERT
       expect(balance).toBe(600);

       acc.Withdraw(100);
       balance = acc.CurrentBalance();
       expect(balance).toBe(500);
   });
});

