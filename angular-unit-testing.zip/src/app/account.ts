export class Account
{
    constructor(private balance: number)
    {

    }
    public Withdraw(amount: number): void
    {
        this.balance -= amount;
    }
    public Deposit(amount: number): void
    {
        this.balance += amount;
    }
    public CurrentBalance(): number
    {
        return this.balance;
    }
}